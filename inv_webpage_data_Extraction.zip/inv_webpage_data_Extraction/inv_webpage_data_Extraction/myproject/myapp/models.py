from django.db import models
class ExcelResult(models.Model):
    valve_set = models.CharField(max_length=255)
    piston_no = models.CharField(max_length=255)
    valve_piece = models.CharField(max_length=255)
    Quantity = models.CharField(max_length=255)


    
class Piston(models.Model):
    piston_id = models.CharField( max_length=50, primary_key=True)
    piston_subtype_1 = models.IntegerField(default=0)
    piston_subtype_2 = models.IntegerField(default=0)
    piston_subtype_3 = models.IntegerField(default=0)
    piston_subtype_4 = models.IntegerField(default=0)
    piston_subtype_5 = models.IntegerField(default=0)
    piston_subtype_6 = models.IntegerField(default=0)
    piston_subtype_7 = models.IntegerField(default=0)
    piston_subtype_8 = models.IntegerField(default=0)
    piston_subtype_9 = models.IntegerField(default=0)
    piston_subtype_10 = models.IntegerField(default=0)
    piston_subtype_11 = models.IntegerField(default=0)
    piston_subtype_12 = models.IntegerField(default=0)
    piston_subtype_13 = models.IntegerField(default=0)
    piston_subtype_14 = models.IntegerField(default=0)
    piston_subtype_15 = models.IntegerField(default=0)
    class Meta:
        db_table = 'pistons'

class ValvePiece(models.Model):
    valve_piece_id = models.CharField(max_length=50, primary_key=True)
    valve_piece_subtype_1 = models.IntegerField(default=0)
    valve_piece_subtype_2 = models.IntegerField(default=0)
    valve_piece_subtype_3 = models.IntegerField(default=0)
    valve_piece_subtype_4 = models.IntegerField(default=0)
    valve_piece_subtype_5 = models.IntegerField(default=0)
    valve_piece_subtype_6 = models.IntegerField(default=0)
    valve_piece_subtype_7 = models.IntegerField(default=0)
    valve_piece_subtype_8 = models.IntegerField(default=0)
    valve_piece_subtype_9 = models.IntegerField(default=0)
    valve_piece_subtype_10 = models.IntegerField(default=0)
    valve_piece_subtype_11 = models.IntegerField(default=0)
    valve_piece_subtype_12 = models.IntegerField(default=0)
    valve_piece_subtype_13 = models.IntegerField(default=0)
    valve_piece_subtype_14 = models.IntegerField(default=0)
    valve_piece_subtype_15 = models.IntegerField(default=0)
    class Meta:
        db_table = 'valvepieces'

class ValveSet(models.Model):
    valve_set_id = models.CharField(max_length=50, primary_key=True)
    piston = models.ForeignKey(Piston, on_delete=models.CASCADE)
    valve_piece = models.ForeignKey(ValvePiece, on_delete=models.CASCADE)
    valve_set_quantity = models.IntegerField()
    class Meta:
        db_table = 'valvesets'




class ValveSetQuantity(models.Model):
    valve_set = models.ForeignKey(ValveSet, on_delete=models.CASCADE)
    piston = models.ForeignKey(Piston, on_delete=models.CASCADE)
    valve_piece = models.ForeignKey(ValvePiece, on_delete=models.CASCADE)
    valve_set_quantity = models.IntegerField()
    class Meta:
        db_table = 'plan'


