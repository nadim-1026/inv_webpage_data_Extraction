from django import forms

class ColumnNameForm(forms.Form):
    column_name = forms.CharField(label='Enter the column name to check')




from .models import ValveSet
from .models import Piston
from .models import ValveSetQuantity
from .models import ValvePiece

class ValveSetForm(forms.ModelForm):
    class Meta:
        # db_table=
        model = ValveSet
        fields = ['valve_set_id', 'piston', 'valve_piece', 'valve_set_quantity']

class ValveSetQuantityForm(forms.ModelForm):
    class Meta:
        model = ValveSetQuantity
        fields = ['valve_set', 'piston', 'valve_piece', 'valve_set_quantity']

class PistonForm(forms.ModelForm):
    class Meta:
        model = Piston
        fields = ['piston_id', 'piston_subtype_1', 'piston_subtype_2', 'piston_subtype_3', 'piston_subtype_4','piston_subtype_5', 'piston_subtype_6', 'piston_subtype_7', 'piston_subtype_8','piston_subtype_9', 'piston_subtype_10', 'piston_subtype_11', 'piston_subtype_12','piston_subtype_13', 'piston_subtype_14', 'piston_subtype_15']

class ValvePieceForm(forms.ModelForm):
    class Meta:
        model = ValvePiece
        fields = ['valve_piece_id', 'valve_piece_subtype_1', 'valve_piece_subtype_2', 'valve_piece_subtype_3', 'valve_piece_subtype_4', 'valve_piece_subtype_5','valve_piece_subtype_6','valve_piece_subtype_7', 'valve_piece_subtype_8','valve_piece_subtype_9','valve_piece_subtype_10', 'valve_piece_subtype_11','valve_piece_subtype_12','valve_piece_subtype_13', 'valve_piece_subtype_14','valve_piece_subtype_15']


