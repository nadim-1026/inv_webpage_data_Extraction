from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import ColumnNameForm
from .models import ExcelResult
import pandas as pd

from django.shortcuts import render

import pandas as pd
from django.http import JsonResponse


# Function to perform data preprocessing
def preprocess_data(file_path):
    # Read Excel file and extract sheet names
    excel_sheets = pd.ExcelFile(file_path).sheet_names

    # Read the specific sheet (e.g., 'Prod Plan1')
    desired_sheet_name = 'Prod Plan1'

    # Check if the desired sheet name is in the list of sheet names
    if desired_sheet_name in excel_sheets:
        # Read the specified sheet
        df = pd.read_excel(file_path, sheet_name=desired_sheet_name)

        # Extract a subset of rows (120:152) and transpose
        data = df.iloc[120:153]
        data1 = data.transpose()

        # Set the first row as column names
        data1.columns = data1.iloc[0]
        data1 = data1[1:].reset_index(drop=True)

        # Remove rows (last 15 rows)
        n_rows_to_remove = 15
        total_rows = len(data1)
        start_index = total_rows - n_rows_to_remove
        data1 = data1.drop(data1.index[start_index:])

        # Remove ' 00:00:00' from column names
        data1.columns = data1.columns.astype(str).str.replace(' 00:00:00', '')

        return data1

    else:
        return None

# Function to get non-NaN values and corresponding information
def get_non_nan_values(data1, column_name):
    data1.columns = data1.columns.astype(str)

    matching_columns = [col for col in data1.columns if col.lower() == column_name.lower()]

    if not matching_columns:
        print(f"Column '{column_name}' not found in the DataFrame.")
        return [], pd.DataFrame(columns=['Valve_Set', 'Piston_No', 'Valve_Piece', column_name])

    non_nan_values = data1[matching_columns[0]].dropna().tolist()
    filtered_df = data1[data1[matching_columns[0]].notna()]
    result_df = filtered_df[['Valve_Set', 'Piston_No', 'Valve_Piece', matching_columns[0]]]

    return non_nan_values, result_df

# Main view function
def extract_data(request):
    if request.method == 'POST':
        form = ColumnNameForm(request.POST)
        if form.is_valid():
            # Get the file path from the form or adjust as needed
            file_path = 'C:\\Users\\NEA1NA\\Documents\\productionplan.xlsx'

            # Perform data preprocessing
            data1 = preprocess_data(file_path)

            if data1 is not None:
                column_name = form.cleaned_data['column_name']

                # Get non-NaN values and corresponding information
                non_nan_values, result_df = get_non_nan_values(data1, column_name)

                # Save result to the database
                ExcelResult.objects.all().delete()  # Clear existing data
                for index, row in result_df.iterrows():
                    ExcelResult.objects.create(
                        valve_set=row['Valve_Set'],
                        piston_no=row['Piston_No'],
                        valve_piece=row['Valve_Piece'],
                        column_value=row[column_name]
                    )

                # Save result to Excel file
                output_excel_path = 'static/output_result.xlsx'
                with pd.ExcelWriter(output_excel_path, engine='openpyxl', mode='w') as writer:
                    result_df.to_excel(writer, index=False, header=True, sheet_name='Result')

                return render(request, 'result.html', {'output_excel_path': output_excel_path})

    else:
        form = ColumnNameForm()

    return render(request, 'extract_data.html', {'form': form})

from django.shortcuts import render

import pandas as pd
from django.http import JsonResponse

def index(request):
    
    return render(request, 'index.html')



from django.shortcuts import render, redirect
#from .models import ValveSet, Piston, ValvePiece, ValveSetQuantity, PistonQuantity, ValvePieceQuantity
from .forms import ValveSetQuantityForm, PistonForm, ValvePieceForm,ValveSetForm
from django.contrib import messages
# views.py
from django.shortcuts import render
from django.http import JsonResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
#from .models import ValveSet, Piston, ValvePiece, ValveSetQuantity, PistonQuantity, ValvePieceQuantity
from .serializers import ValveSetSerializer, PistonSerializer, ValvePieceSerializer
from rest_framework import generics
from .models import ValveSet, Piston, ValvePiece
from .serializers import ValveSetSerializer, PistonSerializer, ValvePieceSerializer
# views.py
from rest_framework.decorators import api_view
import json
from rest_framework.response import Response
from .models import ValveSet, Piston, ValvePiece,ValveSetQuantity
from .serializers import ValveSetSerializer, PistonSerializer, ValvePieceSerializer,ValveSetQuantitySerializer
from rest_framework import status



from django.shortcuts import render
from .models import ValveSet, Piston, ValveSetQuantity, ValvePiece
from .forms import ValveSetForm, PistonForm, ValveSetQuantityForm, ValvePieceForm


def index(request):
    return render(request, 'index.html')


from django.shortcuts import render




from django.http import JsonResponse
from .models import Piston, ValvePiece, ValveSet

@api_view(['PATCH', 'PUT'])
def update_valve_set(request):
    body = json.loads(request.body.decode('utf-8'))
    valveSet = ValveSet(valve_set_id=body["valve_set_id"],  piston_id=body["piston_id"], valve_piece_id=body["valve_piece_id"], valve_set_quantity=body["valve_set_quantity"])
    valveSet.save()

    if True:
        return JsonResponse({
            "success": True,
            "id" : body["valve_set_id"]
        }, safe=False)
    
    else:
        return JsonResponse({'error': 'No Valve Sets data found'})
    body = json.loads(request.body.decode('utf-8'))

@api_view(['PATCH', 'PUT'])
def update_piston(request):
    body = json.loads(request.body.decode('utf-8'))
    print("update piston called", body)
    piston = Piston(piston_id=body["piston_id"], piston_subtype_1=body["piston_subtype_1"], piston_subtype_2=body["piston_subtype_2"], piston_subtype_3=body["piston_subtype_3"], piston_subtype_4=body["piston_subtype_4"], piston_subtype_5=body["piston_subtype_5"], piston_subtype_6=body["piston_subtype_6"], piston_subtype_7=body["piston_subtype_7"], piston_subtype_8=body["piston_subtype_8"], piston_subtype_9=body["piston_subtype_9"], piston_subtype_10=body["piston_subtype_10"], piston_subtype_11=body["piston_subtype_11"], piston_subtype_12=body["piston_subtype_12"], piston_subtype_13=body["piston_subtype_13"], piston_subtype_14=body["piston_subtype_14"], piston_subtype_15=body["piston_subtype_15"])
    piston.save()

    if True:
        return JsonResponse({
            "success": True,
            "id" : body["piston_id"]
        }, safe=False)
    else:
        return JsonResponse({'error': 'No Valve Sets data found'})


@api_view(['PATCH', 'PUT'])
def update_valve_piece(request):
    body = json.loads(request.body.decode('utf-8'))
    valvePiece = ValvePiece(valve_piece_id=body["valve_piece_id"], valve_piece_subtype_1=body["valve_piece_subtype_1"], valve_piece_subtype_2=body["valve_piece_subtype_2"], valve_piece_subtype_3=body["valve_piece_subtype_3"], valve_piece_subtype_4=body["valve_piece_subtype_4"], valve_piece_subtype_5=body["valve_piece_subtype_5"], valve_piece_subtype_6=body["valve_piece_subtype_6"], valve_piece_subtype_7=body["valve_piece_subtype_7"], valve_piece_subtype_8=body["valve_piece_subtype_8"], valve_piece_subtype_9=body["valve_piece_subtype_9"], valve_piece_subtype_10=body["valve_piece_subtype_10"], valve_piece_subtype_11=body["valve_piece_subtype_11"], valve_piece_subtype_12=body["valve_piece_subtype_12"], valve_piece_subtype_13=body["valve_piece_subtype_13"], valve_piece_subtype_14=body["valve_piece_subtype_14"], valve_piece_subtype_15=body["valve_piece_subtype_15"])
    valvePiece.save()

    if True:
        return JsonResponse({
            "success": True,
            "id" : body["valve_piece_id"]
        }, safe=False)
    else:
        return JsonResponse({'error': 'No Valve Sets data found'})


from .serializers import ValveSetSerializer
def get_all_valve_set_data(request):
    valve_sets = ValveSet.objects.all()
    print("All Valve Sets: ", valve_sets)
    data = ValveSetSerializer(valve_sets, many=True);


    if valve_sets:
        return JsonResponse(data.data, safe=False)
    else:
        return JsonResponse({'error': 'No Valve Sets data found'})



def get_valve_set_data(request, id):
    valve_sets = ValveSet.objects.filter(valve_set_id=id).values()
    print(valve_sets)

    if valve_sets:
        return JsonResponse(list(valve_sets)[0], safe=False)
    else:
        return JsonResponse({'error': 'No Valve Sets data found'})




def get_piston_data(request, id):

    piston_data = Piston.objects.filter(piston_id=id).values()
    print(piston_data)
    if piston_data:
        return JsonResponse(list(piston_data)[0], safe=False)
    else:
        return JsonResponse({'error': 'No Piston data found'})

def get_valve_piece_data(request, id):

    valve_piece_data = ValvePiece.objects.filter(valve_piece_id=id).values()
    print(valve_piece_data)
    if valve_piece_data:
        return JsonResponse(list(valve_piece_data)[0], safe=False)
    else:
        return JsonResponse({'error': 'No ValvePiece data found'})



def get_all_valve_piece_data(request):
    valve_piece_data = ValvePiece.objects.order_by('valve_piece_id')[1:2].first()  # You might need to adjust this logic
    if valve_piece_data:
        data = {
            'valve_piece_id': valve_piece_data.valve_piece_id,
            **{f'valve_piece_subtype_{i}': getattr(valve_piece_data, f'valve_piece_subtype_{i}') for i in range(1, 16)}
        }
        return JsonResponse(data)
    else:
        return JsonResponse({'error': 'No ValvePiece data found'})



def get_piston_ids(request):
    piston_ids = Piston.objects.values_list('piston_id', flat=True)
    return JsonResponse({'piston_ids': list(piston_ids)})


def get_valve_piece_ids(request):
    valve_piece_ids = ValvePiece.objects.values_list('valve_piece_id', flat=True)
    return JsonResponse({'valve_piece_ids': list(valve_piece_ids)})
# myapp/views.py


def backlog(request):
    return render(request, 'backlog.html')

import os
import pandas as pd
from django.shortcuts import render
from django.http import HttpResponse
from openpyxl import load_workbook

def get_non_nan_values_backlog(df_backlog, column_name):
    df_backlog.columns = df_backlog.columns.astype(str)

    matching_columns = [col for col in df_backlog.columns if col.lower() == column_name.lower()]

    if not matching_columns:
        print(f"Column '{column_name}' not found in the DataFrame.")
        return [], pd.DataFrame(columns=['Part No','Valve_Piece', 'Piston_No','Overall Backlog', 'Typewise backlog',column_name])

    non_nan_values = df_backlog[matching_columns[0]].dropna().tolist()
    filtered_df = df_backlog[df_backlog[matching_columns[0]].notna()]
    result_df = filtered_df[['Part No','Valve_Piece', 'Piston_No','Overall Backlog', 'Typewise backlog', matching_columns[0]]]
    
    return non_nan_values, result_df

#############focus here ####################################

import os
import pandas as pd
from openpyxl import load_workbook
from django.http import HttpResponse
from django.shortcuts import render

def generate_result(request):
    if request.method == 'POST':
        body = json.loads(request.body.decode('utf-8'))
        print("==================================\n date :", body["date"])
        # Load 'productionplan.xlsx' and perform preprocessing
        production_plan_path = 'C:\\Users\\NEA1NA\\Documents\\productionplan.xlsx'
        desired_plan_sheet_name = 'Prod Plan1'

        production_plan_sheets = pd.ExcelFile(production_plan_path).sheet_names

        if desired_plan_sheet_name in production_plan_sheets:
            # Read the specified sheet
            df_production_plan = pd.read_excel(production_plan_path, sheet_name=desired_plan_sheet_name)

            # Extract the desired range (rows 120 to 152)
            data = df_production_plan.iloc[120:153]
            print("Data after extracting range:")
            print(data)

            data1 = data.transpose()
            data1.columns = data1.iloc[0]
            data1 = data1[1:].reset_index(drop=True)
            n_rows_to_remove = 15
            total_rows = len(data1)
            start_index = total_rows - n_rows_to_remove
            data1 = data1.drop(data1.index[start_index:])
            data1.columns = data1.columns.astype(str).str.replace(' 00:00:00', '')
            print("Data after transposing and removing rows:")
            print(data1)

            # Load '12 Dec'23 Production report v1.xlsm' and perform preprocessing
            excel_file_path = "C:\\Users\\NEA1NA\\Documents\\12 Dec'23 Production report v1.xlsm"
            desired_sheet_name = 'Component_Advance_Backlog'
            header_row = 699

            excel_sheets = pd.ExcelFile(excel_file_path).sheet_names

            if desired_sheet_name in excel_sheets:
                df_backlog = pd.read_excel(excel_file_path, sheet_name=desired_sheet_name, header=header_row)
                print("Dataframe after reading '12 Dec'23 Production report v1.xlsm' sheet:")
                print(df_backlog)

                # Extract the desired range (excluding header row)
                df_backlog.columns = df_backlog.iloc[0]
                df_backlog = df_backlog.iloc[1:]
                n_rows_to_remove = 174
                total_rows = len(df_backlog)
                start_index = total_rows - n_rows_to_remove
                df_backlog = df_backlog.drop(df_backlog.index[start_index:])
                df_backlog = df_backlog.iloc[:, :44]
                df_backlog.columns = df_backlog.columns.astype(str).str.replace(' 00:00:00', '')
                print("Dataframe after removing rows and columns:")
                print(df_backlog)
                data1 = data1.reset_index(drop=True)
                df_backlog = df_backlog.reset_index(drop=True)
                selected_columns = data1[['Valve_Piece', 'Piston_No']]

                # Merge the selected columns into df_backlog
                df_backlog = pd.concat([df_backlog, selected_columns], axis=1)
                print("Dataframe after merging with selected columns:")
                print(df_backlog)

                column_name_to_check = body["date"] 
                # column_name_to_check = request.POST.get('column_name')
                non_nan_values, result_df = get_non_nan_values_backlog(df_backlog, column_name_to_check)
                result_df.rename(columns={column_name_to_check: 'Quantity'}, inplace=True)

                # Save result_df to an Excel file
                output_excel_path = 'static/baclog_result.xlsx'
                if os.path.exists(output_excel_path):
                    # Load the existing workbook
                    book = load_workbook(output_excel_path)
                    # Remove the existing 'Result' sheet if it exists
                    if 'Result' in book.sheetnames:
                        book.remove(book['Result'])
                result_df.to_excel(output_excel_path, index=False, header=True, sheet_name='Result', startrow=1, startcol=0)
                
                return JsonResponse({
                        "success": True,
                        "output_excel_path" : output_excel_path
                        }, safe=False)

            else:
                return JsonResponse({
                    'success' : False,
                    'message' : "The sheet does not exist in the Excel file."
                })
        else:
            return JsonResponse({
                    'success' : False,
                    'message' : "The sheet does not exist in the 'productionplan.xlsx' file."
                })
    else:
        return JsonResponse({
            'success' : False,
            'message'  : "Invalid request method."
        })

    
###########autopopulate function##########################    
def getAlphaNumber(request):
    if request.method == 'GET' and request.is_ajax():
        # Read Excel based on AlphaNo value
        df = pd.read_excel('static/output_result.xlsx')
        print("column name",df.columns)

        ret = []
        for i in range(len(df['Part No'])):
            ret.append(str(df['Part No'][i]))
        print(ret)
        try:
            response_data = {
                'alpha_numbers': ret
            }
            return JsonResponse(response_data)
        except:
            return JsonResponse({'error': 'Invalid request'})
 
def update_field(request):
    if request.method == 'GET' and request.is_ajax():
        AlphaNo_value = str(request.GET.get('AlphaNo_value', None))

        # Read Excel based on AlphaNo value
        df = pd.read_excel('static/output_result.xlsx')
        df['Part No']=df['Part No'].astype(str)
        print(AlphaNo_value)
        # print(AlphaNo_value.type())

        try:
            selected_row = df[df['Part No'] == AlphaNo_value].iloc[0]

            import datetime
           
            
            response_data = {
                'Piston_No': str(selected_row.get('Piston_No', '')),
                'Valve_Piece': str(selected_row.get('Valve_Piece', '')),
                'Quantity': str(selected_row.get('Quantity', '')),
                
            }

            print(response_data)
            return JsonResponse(response_data)
        except:
            return JsonResponse({'error': 'Invalid request'})
        
###############heat map###########################
from django.shortcuts import render
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from io import BytesIO
import base64

from django.shortcuts import render
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from io import BytesIO
import base64

def generate_heatmap(excel_path):
    # Read the Excel sheet
    result_df = pd.read_excel(excel_path)

    print(result_df.head())

    # Identify non-numeric values in 'Overall Backlog'
    non_numeric_values = result_df['Overall Backlog'][pd.to_numeric(result_df['Overall Backlog'], errors='coerce').isna()]

    # Drop rows with non-numeric values in 'Overall Backlog' column
    result_df = result_df[pd.to_numeric(result_df['Overall Backlog'], errors='coerce').notna()]

    # Define custom color ranges
    cmap_custom = sns.diverging_palette(150, 10, s=80, l=60, n=4, as_cmap=True)
    custom_colors = ["green", "yellow", "orange", "darkorange", "red"]

    # Create a table for the data
    table_html = result_df.to_html(classes='table table-striped table-bordered')

    # Define custom colorbar
    cbar_kws = {"ticks": [0, 500, 2000, 4000, result_df['Overall Backlog'].max()], "label": "Overall Backlog"}

    # Pivot the DataFrame for creating a heatmap
    heatmap_data = result_df.pivot('Valve_Piece')

    # Create a heatmap with custom colors and colorbar
    plt.figure(figsize=(12, 8))
    sns.heatmap(heatmap_data, annot=True, fmt=".0f", cmap=cmap_custom, linewidths=.5, cbar_kws=cbar_kws, vmin=0, vmax=result_df['Overall Backlog'].max())
    plt.title('Heatmap of Overall Backlog')

    # Save the plot to a BytesIO object
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)

    # Encode the plot as base64 string
    plot_image = base64.b64encode(buffer.read()).decode('utf-8')

    return table_html, plot_image

def heatmap(request):
    print("heatmap view is called")
    # Assuming you pass the Excel file path to the function
    excel_path = 'static/output_result.xlsx'
    table_html, plot_image = generate_heatmap(excel_path)

    context = {
        'table_html': table_html,
        'heatmap': plot_image,
    }

    return render(request, 'heatmap.html', context)