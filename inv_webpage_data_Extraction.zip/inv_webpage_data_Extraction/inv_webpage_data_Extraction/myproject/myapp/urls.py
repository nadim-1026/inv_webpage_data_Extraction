from django.urls import path

from .views import index,heatmap, update_field, getAlphaNumber,extract_data,get_piston_data,get_valve_set_data, get_all_valve_set_data, get_valve_piece_data,update_piston, update_valve_piece, update_valve_set
from .import views
urlpatterns = [
    path('extract_data/', extract_data, name='extract_data'),
    path('', views.index, name='index'),
    path('update-fields/', update_field, name='update_fields'),
    path('get-all-alpha-numbers/', getAlphaNumber, name='get-all-alpha-numbers'),
  
   # path('/text',text),
    path('', views.index, name='index'),
    # path('api/v1/valvesets/', ValveSetListCreateView.as_view(), name='valveset-list-create'),
    # path('api/v1/pistons/<int:pk>/', PistonRetrieveUpdateView.as_view(), name='piston-retrieve-update'),
    # path('api/v1/valve-pieces/<int:pk>/', ValvePieceRetrieveUpdateView.as_view(), name='valvepiece-retrieve-update'),

    #path('api/v1/valve-pieces/<str:valve_piece_id>/', get_valve_piece),
    #path('api/v1/valve-pieces/', update_valve_piece),
    #path('api/v1/valvesetquantity/', update_valve_set_quantity),
    #path('api/v1/get-pistons/<str:piston_id>/', get_piston),
    path('get_all_valve_set_data/', get_all_valve_set_data,name='get_all_valve_set_data'),
    path('get_valve_set_data/<str:id>', get_valve_set_data,name='get_valve_set_data'),
    path('get_piston_data/<str:id>', get_piston_data,name='get_piston_data'),
    path('get_valve_piece_data/<str:id>', get_valve_piece_data,name='get_valve_piece_data'),

    path('update-valve-set/', update_valve_set),
    path('update-piston/', update_piston),
    path('update-valve-piece/', update_valve_piece),
    path('generate_result/', views.generate_result, name='generate_result'),
    path('backlog/', views.backlog, name='backlog'),
    path('heatmap/', heatmap, name='heatmap'),# Add this line
    
]