# -*- coding: utf-8 -*-
# myapp/utils.py
import pandas as pd

def get_non_nan_values_backlog(df_backlog, column_name):
    df_backlog.columns = df_backlog.columns.astype(str)

    matching_columns = [col for col in df_backlog.columns if col.lower() == column_name.lower()]

    if not matching_columns:
        print(f"Column '{column_name}' not found in the DataFrame.")
        return [], pd.DataFrame(columns=['Part No','Valve_Piece', 'Piston_No','Overall Backlog', 'Typewise backlog',column_name])

    non_nan_values = df_backlog[matching_columns[0]].dropna().tolist()
    filtered_df = df_backlog[df_backlog[matching_columns[0]].notna()]
    result_df = filtered_df[['Part No','Valve_Piece', 'Piston_No','Overall Backlog', 'Typewise backlog', matching_columns[0]]]
    
    return non_nan_values, result_df
